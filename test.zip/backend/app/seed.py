"""
Скрипт первоначального заполнения базы данных демонстрационными данными
(соответствует данным из Лабораторной работы №1).
"""
import sys
import os

# Добавление корневой папки backend в sys.path для корректных импортов
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import SessionLocal, init_db
from app.models.photo import Photo
from app.models.task import Task


def seed():
    print("Инициализация таблиц базы данных...")
    init_db()

    db = SessionLocal()
    try:
        # Проверка, есть ли уже данные
        existing = db.query(Photo).first()
        if existing:
            print("База данных уже содержит данные. Пропуск наполнения.")
            return

        print("Добавление демонстрационных данных...")

        photo1 = Photo(
            filename="street_lenina_01.jpg",
            image_url="https://images.unsplash.com/photo-1545459720-aac8509eb02c?auto=format&fit=crop&w=800&q=80",
            address="ул. Ленина, д. 42",
            status="processed",
            issues_count=2,
            error_message=None,
        )
        photo2 = Photo(
            filename="prospekt_mira_15.jpg",
            image_url="https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?auto=format&fit=crop&w=800&q=80",
            address="пр. Мира, д. 15",
            status="processed",
            issues_count=1,
            error_message=None,
        )
        photo3 = Photo(
            filename="crossroad_sovetskaya.jpg",
            image_url="https://images.unsplash.com/photo-1517649763962-0c623266ddc0?auto=format&fit=crop&w=800&q=80",
            address="перекрёсток Советская / Гагарина",
            status="processing",
            issues_count=0,
            error_message=None,
        )
        photo4 = Photo(
            filename="highway_m7_km12.jpg",
            image_url="https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=800&q=80",
            address="Трасса М-7, 12-й км",
            status="error",
            issues_count=0,
            error_message="Ошибка сегментации разметки: низкое качество кадра из-за бликов солнца и дождя.",
        )

        db.add_all([photo1, photo2, photo3, photo4])
        db.commit()

        # Добавление связанных заданий на ремонт
        task1 = Task(
            photo_id=photo1.id,
            description="Восстановление сплошной линии разметки (износ > 60%)",
            address="ул. Ленина, д. 42",
            priority="high",
            status="pending",
        )
        task2 = Task(
            photo_id=photo1.id,
            description="Обновление разметки пешеходного перехода «зебра»",
            address="ул. Ленина, д. 42",
            priority="medium",
            status="in_progress",
        )
        task3 = Task(
            photo_id=photo2.id,
            description="Нанесение разметки стрелы направления движения по полосам",
            address="пр. Мира, д. 15",
            priority="low",
            status="completed",
        )

        db.add_all([task1, task2, task3])
        db.commit()

        print("Демонстрационные данные успешно внесены в базу данных!")
    finally:
        db.close()


if __name__ == "__main__":
    seed()
