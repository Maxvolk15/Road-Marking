from pydantic import BaseModel, Field


class DashboardStatsResponse(BaseModel):
    """Сводная статистика для главного экрана (Dashboard)."""
    total_photos: int = Field(..., ge=0, description="Общее количество загруженных фотографий")
    processed_photos: int = Field(..., ge=0, description="Количество успешно обработанных фотографий")
    total_tasks: int = Field(..., ge=0, description="Всего сформировано ремонтных заданий")
    pending_tasks: int = Field(..., ge=0, description="Количество активных/незавершенных заданий")
