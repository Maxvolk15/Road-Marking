from datetime import datetime
from enum import Enum
from typing import Optional
from pydantic import BaseModel, ConfigDict, Field


class TaskPriority(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class TaskStatus(str, Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"


class TaskBase(BaseModel):
    """Базовые атрибуты задания на ремонт."""
    description: str = Field(..., min_length=3, max_length=1000, description="Описание необходимых ремонтных работ")
    address: str = Field(..., min_length=2, max_length=255, description="Адрес участка дороги")
    priority: TaskPriority = Field(default=TaskPriority.MEDIUM, description="Приоритет выполнения задачи")
    status: TaskStatus = Field(default=TaskStatus.PENDING, description="Текущий статус задания")


class TaskCreate(TaskBase):
    """Схема создания нового задания с указанием связанной фотографии."""
    photo_id: int = Field(..., gt=0, description="Идентификатор связанной фотографии (внешний ключ)")


class TaskCreateForPhoto(TaskBase):
    """Схема создания задания через вложенный роут фотографии (photo_id берется из пути)."""
    pass


class TaskUpdate(BaseModel):
    """Схема для частичного или полного обновления задания."""
    description: Optional[str] = Field(None, min_length=3, max_length=1000)
    address: Optional[str] = Field(None, min_length=2, max_length=255)
    priority: Optional[TaskPriority] = None
    status: Optional[TaskStatus] = None
    photo_id: Optional[int] = Field(None, gt=0)


class TaskResponse(TaskBase):
    """Схема ответа API с полной информацией о задании."""
    id: int
    photo_id: int
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)
