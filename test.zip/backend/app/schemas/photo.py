from datetime import datetime
from enum import Enum
from typing import List, Optional
from pydantic import BaseModel, ConfigDict, Field, HttpUrl

from app.schemas.task import TaskResponse


class PhotoStatus(str, Enum):
    PROCESSING = "processing"
    PROCESSED = "processed"
    ERROR = "error"


class PhotoBase(BaseModel):
    """Базовые атрибуты фотографии дорожного полотна."""
    filename: str = Field(..., min_length=1, max_length=255, description="Имя исходного файла")
    image_url: str = Field(..., min_length=1, max_length=1000, description="URL изображения или путь к файлу")
    address: str = Field(..., min_length=2, max_length=255, description="Адрес участка дороги")
    status: PhotoStatus = Field(default=PhotoStatus.PROCESSING, description="Статус обработки изображения")
    issues_count: int = Field(default=0, ge=0, description="Количество обнаруженных дефектов разметки")
    error_message: Optional[str] = Field(None, max_length=1000, description="Сообщение об ошибке анализа (если status=error)")


class PhotoCreate(BaseModel):
    """Схема создания записи о фотографии."""
    filename: str = Field(..., min_length=1, max_length=255)
    image_url: str = Field(..., min_length=1, max_length=1000)
    address: str = Field(..., min_length=2, max_length=255)
    status: PhotoStatus = Field(default=PhotoStatus.PROCESSING)
    issues_count: int = Field(default=0, ge=0)
    error_message: Optional[str] = Field(None, max_length=1000)


class PhotoUpdate(BaseModel):
    """Схема частичного обновления записи о фотографии."""
    filename: Optional[str] = Field(None, min_length=1, max_length=255)
    image_url: Optional[str] = Field(None, min_length=1, max_length=1000)
    address: Optional[str] = Field(None, min_length=2, max_length=255)
    status: Optional[PhotoStatus] = None
    issues_count: Optional[int] = Field(None, ge=0)
    error_message: Optional[str] = Field(None, max_length=1000)


class PhotoResponse(PhotoBase):
    """Схема ответа API с метаданными фотографии."""
    id: int
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


class PhotoDetailResponse(PhotoResponse):
    """Схема детального ответа API с включением списка связанных заданий на ремонт."""
    tasks: List[TaskResponse] = []

    model_config = ConfigDict(from_attributes=True)
